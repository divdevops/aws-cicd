#!/bin/bash
cd /home/ec2-user/myapp
npm install
