#!/bin/bash
pkill node || true
